module.exports = {
    AMARILLO :1,
    AZUL : 2,
    ROJO : 3,
    VERDE : 4
}