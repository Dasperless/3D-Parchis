module.exports = {
    CASA: 0,
    TABLERO : 1,
    PASILLO : 2,
    GANO : 3
}
