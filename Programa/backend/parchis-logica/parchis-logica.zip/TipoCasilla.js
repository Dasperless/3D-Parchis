module.exports = {
    NORMAL : 0,
    SEGURA : 1,
    INICIO : 2,
    PASILLO: 3,
    META : 4
}
